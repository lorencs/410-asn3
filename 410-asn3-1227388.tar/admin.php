<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<HTML>	
	<HEAD>
		<meta http-equiv="Content-type" content="text/html;charset=UTF-8">
		<style type="text/css">
			body{font-family: Calibri, Candara, Segoe, "Segoe UI", Optima, Arial, sans-serif;}
		</style>
		<LINK REL=STYLESHEET HREF="design.css" TYPE="text/CSS">
		<TITLE>CMPUT410 Assignment 3 - Results Page</TITLE>	
		<script language="JavaScript" src="functions.js" ></script>
	
	</HEAD>
	
	<BODY>
		
		
		<table class="shadow" border="0" cellpadding="2" cellspacing="0" width="900px" align="center">					
			<tr><td class="header2"><h1><br>Admin Module</h1></td></tr>
				
			<tr>
				<td class="footer"> 
					<div class="extra-pad">
						<?php
						include 'phpfuncs.php';	
				
						generateAdminPage();					
						
						?>
						
		</table><br><br>
		
		
		
	</BODY>
</HTML>

